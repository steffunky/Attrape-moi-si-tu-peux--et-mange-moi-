var ai_8cxx =
[
    [ "AILevel0", "ai_8cxx.html#a46b2d73f3ac92020485693b9df098ded", null ],
    [ "AILevel1", "ai_8cxx.html#a53639a950aff66d33c2b5083c5d5b267", null ],
    [ "distance", "ai_8cxx.html#aff8f2b6966de61cc5f0a66ac305b500a", null ],
    [ "Substract", "ai_8cxx.html#ad4114f11a5a56c6e6dae89cf5f5b8cd9", null ]
];