var searchData=
[
  ['substract',['Substract',['../ai_8cxx.html#ad4114f11a5a56c6e6dae89cf5f5b8cd9',1,'Substract(CPosition arg1, CPosition arg2):&#160;ai.cxx'],['../catch_8hxx.html#ad4114f11a5a56c6e6dae89cf5f5b8cd9',1,'Substract(CPosition arg1, CPosition arg2):&#160;ai.cxx']]]
];
