var searchData=
[
  ['distance',['distance',['../ai_8cxx.html#aff8f2b6966de61cc5f0a66ac305b500a',1,'distance(CPosition &amp;PosPlayer1, CPosition &amp;PosPlayer2):&#160;ai.cxx'],['../catch_8hxx.html#aff8f2b6966de61cc5f0a66ac305b500a',1,'distance(CPosition &amp;PosPlayer1, CPosition &amp;PosPlayer2):&#160;ai.cxx']]]
];
